package com.example.quizybee.activity;

import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.quizybee.R;
import com.example.quizybee.model.TestModel;
import com.example.quizybee.adapter.TestAdapter;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.util.ArrayList;
import java.util.List;

public class TestActivity extends AppCompatActivity {

    private RecyclerView testview;
    private Toolbar toolbar;
    private List<TestModel> testList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test);


        String cat_index = getIntent().getStringExtra("CAT_INDEX");
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar()!=null){
            getSupportActionBar().show();
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }
        testview = findViewById(R.id.test_recycler_view);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        layoutManager.setOrientation(RecyclerView.VERTICAL);
        testview.setLayoutManager(layoutManager);

        loadTestData(cat_index);


    }

    private void loadTestData(String catId) {
        testList = new ArrayList<TestModel>();
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        db.collection("categories").document(catId)
                .collection("test")
                .get()
                .addOnSuccessListener(querySnapshot -> {
                    for (QueryDocumentSnapshot document : querySnapshot) {
                        String testName = document.getString("name");
                        //int progress = document.contains("progress") ? document.getLong("progress").intValue() : 0;
                        testList.add(new TestModel(document.getId(),testName,catId));
                    }
                    TestAdapter adapter = new TestAdapter(testList);
                    testview.setAdapter(adapter);
                })
                .addOnFailureListener(e -> Log.e("FirestoreError", "Error fetching tests: " + e.getMessage()));

    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            TestActivity.this.finish();
        }
        return super.onOptionsItemSelected(item);
    }
}
