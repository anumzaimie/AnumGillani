package com.example.quizybee.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.quizybee.R;
import com.example.quizybee.model.LeaderboardModel;

import java.util.List;


public class LeaderBoardAdapter extends RecyclerView.Adapter<LeaderBoardAdapter.UserViewHolder> {
    private List<LeaderboardModel> leaderboardItems;

    public LeaderBoardAdapter(List<LeaderboardModel> leaderboardItems) {
        this.leaderboardItems = leaderboardItems;
    }

    @NonNull
    @Override
    public UserViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_user, parent, false);
        return new UserViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull UserViewHolder holder, int position) {
       /* User user = userList.get(position);
        holder.userName.setText(user.getName());
        holder.userScore.setText("Score: " + user.getScore());
        holder.userRank.setText("Rank - " + user.getRank());
        holder.userInitial.setText(user.getInitials());*/
        LeaderboardModel model=leaderboardItems.get(position);
        holder.userInitial.setText(String.valueOf(model.getUserName().charAt(0)));
        holder.userName.setText(model.getUserName());
        holder.userScore.setText("Score: " + model.getScore());
        holder.userRank.setText("Rank - " + model.getRank());
    }


    @Override
    public int getItemCount() {
       return leaderboardItems.size();
    }

    public static class UserViewHolder extends RecyclerView.ViewHolder {
        TextView userName, userScore, userRank, userInitial;

        public UserViewHolder(@NonNull View itemView) {
            super(itemView);
            userName = itemView.findViewById(R.id.user_name);
            userScore = itemView.findViewById(R.id.user_score);
            userRank = itemView.findViewById(R.id.user_rank);
            userInitial = itemView.findViewById(R.id.user_initial);
        }
    }
}
