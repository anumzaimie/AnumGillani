package com.example.quizybee.adapter;

import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.quizybee.R;
import com.example.quizybee.model.QuestionModel;

import java.util.List;

public class AnswersAdapter extends RecyclerView.Adapter<AnswersAdapter.AnswersViewHolder> {

    private final List<QuestionModel> questionList;

    public AnswersAdapter(List<QuestionModel> questionList) {
        this.questionList = questionList;
    }

    @NonNull
    @Override
    public AnswersViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_answer, parent, false);
        return new AnswersViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull AnswersViewHolder holder, int position) {
        QuestionModel question = questionList.get(position);

        // Set question number and text
        holder.tvQuestionNumber.setText("Question No. " + (position + 1));
        holder.tvQuestionText.setText(question.getQuestion());

        // Set options
        holder.tvOptionA.setText("A. " + question.getOptions().get(0));
        holder.tvOptionB.setText("B. " + question.getOptions().get(1));
        holder.tvOptionC.setText("C. " + question.getOptions().get(2));
        holder.tvOptionD.setText("D. " + question.getOptions().get(3));

        // Highlight selected and correct options
        if (question.getSelectedAnswer().equals(question.getCorrectAnswer())) {
            holder.tvStatus.setText("CORRECT");
            holder.tvStatus.setTextColor(Color.GREEN);
        } else {
            holder.tvStatus.setText("WRONG");
            holder.tvStatus.setTextColor(Color.RED);
        }

        // Highlight user-selected option
        TextView selectedOption = holder.getOptionView(question.getSelectedAnswer(), question);
        if (selectedOption != null) {
            selectedOption.setTextColor(Color.RED);
        }

        // Highlight correct option
        TextView correctOption = holder.getOptionView(question.getCorrectAnswer(),question);
        if (correctOption != null) {
            correctOption.setTextColor(Color.GREEN);
        }
    }

    @Override
    public int getItemCount() {
        return questionList.size();
    }

    public static class AnswersViewHolder extends RecyclerView.ViewHolder {
        TextView tvQuestionNumber, tvQuestionText, tvOptionA, tvOptionB, tvOptionC, tvOptionD, tvStatus;

        public AnswersViewHolder(@NonNull View itemView) {
            super(itemView);
            tvQuestionNumber = itemView.findViewById(R.id.tv_question_number);
            tvQuestionText = itemView.findViewById(R.id.tv_question_text);
            tvOptionA = itemView.findViewById(R.id.tv_option_a);
            tvOptionB = itemView.findViewById(R.id.tv_option_b);
            tvOptionC = itemView.findViewById(R.id.tv_option_c);
            tvOptionD = itemView.findViewById(R.id.tv_option_d);
            tvStatus = itemView.findViewById(R.id.tv_status);
        }

        public TextView getOptionView(String option, QuestionModel model) {
            if (option.equals(model.getOptions().get(0))) {
                return tvOptionA;
            } else if (option.equals(model.getOptions().get(1))) {
                return tvOptionB;

            } else if (option.equals(model.getOptions().get(2))) {
                return tvOptionC;

            } else if (option.equals(model.getOptions().get(3))) {
                return tvOptionD;

            }
            return tvOptionD;
        }
    }
}
