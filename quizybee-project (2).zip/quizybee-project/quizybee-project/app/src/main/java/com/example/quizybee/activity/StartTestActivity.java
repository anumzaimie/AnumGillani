package com.example.quizybee.activity;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.quizybee.R;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

public class StartTestActivity extends BaseActivity {


    private TextView catName, testNo, totalQ, bestScore, time;
    private Button startTestB;
    private ImageView backB;
    FirebaseFirestore db;
    String totalMarks;
    Dialog dialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start_test);
        String catId = getIntent().getStringExtra("cat_id");
        String testId = getIntent().getStringExtra("test_id");
        db = FirebaseFirestore.getInstance();
        init();
        dialog=getProgressDialog(false);
        fetchQuizDetails(catId, testId);
        startTestB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), QuestionsActivity.class);
                intent.putExtra("cat_id", catId);
                intent.putExtra("test_id", testId);
                intent.putExtra("time",time.getText().toString());
                intent.putExtra("cat_name",catName.getText().toString());
                intent.putExtra("t_marks",totalMarks);

                startActivity(intent);
            }
        });
        backB.setOnClickListener(v -> finish());

    }

    private void init() {
        catName = findViewById(R.id.st_cat_name);
        testNo = findViewById(R.id.st_test_no);
        totalQ = findViewById(R.id.st_total_ques);
        bestScore = findViewById(R.id.st_best_score);
        time = findViewById(R.id.st_time);
        startTestB = findViewById(R.id.start_testB);
        backB = findViewById(R.id.st_backB);
        if (getSupportActionBar() != null) { getSupportActionBar().hide(); }
        backB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                StartTestActivity.this.finish();
            }

        });


    }

    private void fetchQuizDetails(String catId, String testId) {
        // Navigate to document in Firestore
        showProgressDialog(dialog);
        db.collection("categories")
                .document(catId)
                .collection("test")
                .document(testId)
                .get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        DocumentSnapshot document = task.getResult();
                        if (document.exists()) {
                            // Extract data from the document
                            String testName = document.getString("name");
                            int _bestScore = document.get("Best Score",Integer.class);
                            String _time = document.getString("time");
                            totalMarks=document.getString("totalMarks");
                            testNo.setText(testName);
                            bestScore.setText("" + _bestScore);
                            time.setText("" + _time);
                            fetchQuestionsCount(catId, testId);
                            fetchCategoryName(catId);
                        } else {
                            cancelDialog(dialog);
                            Toast.makeText(this, "Document does not exist!", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        cancelDialog(dialog);
                        Log.e("FirestoreError", "Error fetching document", task.getException());
                    }
                });
    }

    private void fetchCategoryName(String catId){
        db.collection("categories").document(catId).get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
            @Override
            public void onSuccess(DocumentSnapshot documentSnapshot) {
           catName.setText(documentSnapshot.getString("name"));
            }
        });
    }
    private void fetchQuestionsCount(String catId, String testId) {
        db.collection("categories")
                .document(catId)
                .collection("test")
                .document(testId)
                .collection("questions")
                .get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        int questionsCount = task.getResult().size();
                        totalQ.setText(""+questionsCount);
                        cancelDialog(dialog);

                    } else {
                        cancelDialog(dialog);
                        Log.e("FirestoreError", "Error fetching questions", task.getException());
                    }
                });
    }
}
