package com.example.quizybee.model;

public class QuizSubmission {
    private String userId;
    private String testId;
    private int score;
    private long timestamp;

    public QuizSubmission() {
        // Default constructor required for Firestore serialization
    }

    public QuizSubmission(String userId, String testId, int score) {
        this.userId = userId;
        this.testId = testId;
        this.score = score;
        this.timestamp = System.currentTimeMillis();
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getTestId() {
        return testId;
    }

    public void setTestId(String testId) {
        this.testId = testId;
    }

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }
}
