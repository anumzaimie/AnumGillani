package com.example.quizybee.fragment;

import android.app.Dialog;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridView;
import android.widget.Toast;

import com.example.quizybee.adapter.CategoryAdapter;
import com.example.quizybee.model.CategoryModel;
import com.example.quizybee.R;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.util.ArrayList;
import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link CategoryFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class CategoryFragment extends BaseFragment {
    private FirebaseFirestore db;

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;
    Dialog dialog;
    public CategoryFragment() {
        // Required empty public constructor
    }

    private GridView catView;
    public  List<CategoryModel> catList = new ArrayList<>();

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment CategoryFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static CategoryFragment newInstance(String param1, String param2) {
        CategoryFragment fragment = new CategoryFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_category, container, false);
        catView = view.findViewById(R.id.cat_Grid);

        loadCategories();


        return view;
    }

    private void loadCategories() {
        db = FirebaseFirestore.getInstance();
        catList.clear();
        dialog = getProgressDialog(false);
        showProgressDialog(dialog);

        db.collection("categories").get().addOnSuccessListener(querySnapshot -> {
            for (QueryDocumentSnapshot document : querySnapshot) {
                String id = document.getId();
                String name = document.getString("name");

                // Fetch the count of "test" documents in the subcollection
                db.collection("categories")
                        .document(id)
                        .collection("test")
                        .get()
                        .addOnSuccessListener(testSnapshot -> {
                            int testCount = testSnapshot.size(); // Count the documents in the "test" subcollection
                            catList.add(new CategoryModel(id, name, testCount));

                            // Notify the adapter once all categories are processed
                            if (catList.size() == querySnapshot.size()) {
                                CategoryAdapter adapter = new CategoryAdapter(catList);
                                catView.setAdapter(adapter);
                                cancelDialog(dialog);
                            }
                        })
                        .addOnFailureListener(e -> {
                            Toast.makeText(getContext(), "Error fetching test count: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                            Log.d("Failure==>>>", e.getMessage());
                            cancelDialog(dialog);
                        });
            }
        }).addOnFailureListener(e -> {
            Toast.makeText(getContext(), "Error fetching categories: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            Log.d("Failure==>>>", e.getMessage());
            cancelDialog(dialog);
        });
    }



}