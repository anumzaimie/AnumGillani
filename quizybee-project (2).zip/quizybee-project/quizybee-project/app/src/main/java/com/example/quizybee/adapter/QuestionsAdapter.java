package com.example.quizybee.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.quizybee.R;
import com.example.quizybee.model.QuestionModel;

import java.util.List;

public class QuestionsAdapter extends RecyclerView.Adapter<QuestionsAdapter.ViewHolder> {

    private List<QuestionModel> questionList;
    private int totalMarks;
    private int questionMarks;
    private int[] questionScores;
    private boolean[] isAnswered;
    private int[] selectedAnswers; // Track which option is selected for each question
    private int[] answerStatus;// -1: unattempted, 0: wrong, 1: correct

    public QuestionsAdapter(List<QuestionModel> questionList, int totalMarks) {
        this.questionList = questionList;
        this.totalMarks = totalMarks;
        this.questionMarks = totalMarks / questionList.size();
        this.isAnswered = new boolean[questionList.size()];
        this.questionScores = new int[questionList.size()];
        this.selectedAnswers = new int[questionList.size()]; // Initialize with -1 for no selection
        for (int i = 0; i < selectedAnswers.length; i++) {
            selectedAnswers[i] = -1;
        }
        this.answerStatus = new int[questionList.size()];
        for (int i = 0; i < selectedAnswers.length; i++) {
            selectedAnswers[i] = -1;
            answerStatus[i] = -1; // -1 means unattempted
        }
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_question, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        QuestionModel model = questionList.get(position);

        // Remove the listener temporarily to prevent unwanted triggers
        holder.radioGroup.setOnCheckedChangeListener(null);

        holder.tvQuestion.setText(model.getQuestion());
        holder.optionA.setText(model.getOptions().get(0));
        holder.optionB.setText(model.getOptions().get(1));
        holder.optionC.setText(model.getOptions().get(2));
        holder.optionD.setText(model.getOptions().get(3));

        holder.tvReviewLabel.setVisibility(model.isReview() ? View.VISIBLE : View.GONE);

        // Restore previous selection if any
        holder.radioGroup.clearCheck();
        if (selectedAnswers[position] != -1) {
            switch (selectedAnswers[position]) {
                case 0:
                    holder.optionA.setChecked(true);
                    break;
                case 1:
                    holder.optionB.setChecked(true);
                    break;
                case 2:
                    holder.optionC.setChecked(true);
                    break;
                case 3:
                    holder.optionD.setChecked(true);
                    break;
            }
        }

        // Re-add the listener
        /*holder.radioGroup.setOnCheckedChangeListener((group, checkedId) -> {
            int selectedIndex = -1;
            String selectedAnswer = "";
            model.setAnswered(true);
            if (checkedId == R.id.optionA) {
                selectedIndex = 0;
                selectedAnswer = model.getOptions().get(0);
            } else if (checkedId == R.id.optionB) {
                selectedIndex = 1;
                selectedAnswer = model.getOptions().get(1);
            } else if (checkedId == R.id.optionC) {
                selectedIndex = 2;
                selectedAnswer = model.getOptions().get(2);
            } else if (checkedId == R.id.optionD) {
                selectedIndex = 3;
                selectedAnswer = model.getOptions().get(3);
            }

            if (checkedId == -1) {
                // Only clear if it was previously answered
                if (isAnswered[position]) {
                    questionScores[position] = 0;
                    isAnswered[position] = false;
                    selectedAnswers[position] = -1;
                }
            } else {
                selectedAnswers[position] = selectedIndex;
                isAnswered[position] = true;
                boolean isCorrect = selectedAnswer.equals(model.getCorrectAnswer());
                questionScores[position] = isCorrect ? questionMarks : 0;
            }
        });*/
        holder.radioGroup.setOnCheckedChangeListener((group, checkedId) -> {
            int selectedIndex = -1;
            String selectedAnswer = "";
            model.setAnswered(true);

            if (checkedId == R.id.optionA) {
                selectedIndex = 0;
                selectedAnswer = model.getOptions().get(0);
            } else if (checkedId == R.id.optionB) {
                selectedIndex = 1;
                selectedAnswer = model.getOptions().get(1);
            } else if (checkedId == R.id.optionC) {
                selectedIndex = 2;
                selectedAnswer = model.getOptions().get(2);
            } else if (checkedId == R.id.optionD) {
                selectedIndex = 3;
                selectedAnswer = model.getOptions().get(3);
            }

            if (checkedId == -1) {
                if (isAnswered[position]) {
                    questionScores[position] = 0;
                    isAnswered[position] = false;
                    selectedAnswers[position] = -1;
                    answerStatus[position] = -1; // Mark as unattempted
                    model.setSelectedAnswer("");
                }
            } else {
                selectedAnswers[position] = selectedIndex;
                isAnswered[position] = true;
                model.setSelectedAnswer(selectedAnswer);

                boolean isCorrect = selectedAnswer.equals(model.getCorrectAnswer());
                questionScores[position] = isCorrect ? questionMarks : 0;
                answerStatus[position] = isCorrect ? 1 : 0; // 1 for correct, 0 for wrong
            }
        });
    }

    @Override
    public int getItemCount() {
        return questionList.size();
    }

    public int getCorrectAnswersCount() {
        int count = 0;
        for (int status : answerStatus) {
            if (status == 1) count++;
        }
        return count;
    }

    public int getWrongAnswersCount() {
        int count = 0;
        for (int status : answerStatus) {
            if (status == 0) count++;
        }
        return count;
    }

    public int getScore() {
        int totalScore = 0;
        for (int score : questionScores) {
            totalScore += score;
        }
        return totalScore;
    }

    public void clearOptionForQuestion(int position) {
        if (position >= 0 && position < questionList.size() && isAnswered[position]) {
            questionScores[position] = 0;
            isAnswered[position] = false;
            selectedAnswers[position] = -1;
            notifyItemChanged(position);
        }
    }

    public void markForReview(int position) {
        if (position >= 0 && position < questionList.size()) {
            questionList.get(position).setReview(true);
            notifyItemChanged(position);
        }
    }

    public void bookmark(int position, boolean status) {
        if (position >= 0 && position < questionList.size()) {
            questionList.get(position).setBookmark(status);
            notifyItemChanged(position);
        }
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvQuestion, tvReviewLabel;
        RadioGroup radioGroup;
        RadioButton optionA, optionB, optionC, optionD;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvQuestion = itemView.findViewById(R.id.tv_question);
            tvReviewLabel = itemView.findViewById(R.id.tv_review_label);
            radioGroup = itemView.findViewById(R.id.options_group);
            optionA = itemView.findViewById(R.id.optionA);
            optionB = itemView.findViewById(R.id.optionB);
            optionC = itemView.findViewById(R.id.optionC);
            optionD = itemView.findViewById(R.id.optionD);
        }
    }
}