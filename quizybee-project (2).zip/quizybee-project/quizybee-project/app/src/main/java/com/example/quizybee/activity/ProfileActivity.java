package com.example.quizybee.activity;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.cloudinary.android.MediaManager;
import com.cloudinary.android.callback.ErrorInfo;
import com.cloudinary.android.callback.UploadCallback;
import com.example.quizybee.R;
import com.example.quizybee.utils.FileUtils;
import com.google.android.gms.cast.tv.media.MediaManager;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class ProfileActivity extends TakePhotoActivity implements SeekBar.OnSeekBarChangeListener {
    private ImageView profileImage;
    private EditText editTextName, editTextEmail;
    SeekBar ageBar;
    TextView txtAge;
    private RadioGroup radioGroupGender;
    private RadioButton radioMale, radioFemale;
    private Spinner spinnerCountry;
    private CheckBox checkboxDesigning, checkboxSoftwareEngr, checkboxProgramming, checkboxWebAppDevelopment;
    String[] countries = {"Select Country", "Pakistan", "United States", "Canada", "United Kingdom", "Australia", "India"};
    private FirebaseStorage storage = FirebaseStorage.getInstance();
    private StorageReference storageRef = storage.getReference();
    Button btnSave;
    Dialog dialog;
    String imageUrl;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_profile);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        init();
        initializeImagePicker();
        setSpinnerAdapter();
        fetchUserData();
        profileImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showChoosePhotoDialog();
            }
        });
        btnSave.setOnClickListener(v -> saveUserData());
    }

    public void init() {
        // Initialize UI components
        profileImage = findViewById(R.id.profileImage);
        editTextName = findViewById(R.id.editTextName);
        editTextEmail = findViewById(R.id.editTextEmail);
        txtAge = findViewById(R.id.ageTxt);
        ageBar = findViewById(R.id.progressBarAge);
        radioGroupGender = findViewById(R.id.radioGroupGender);
        radioMale = findViewById(R.id.radioMale);
        radioFemale = findViewById(R.id.radioFemale);
        spinnerCountry = findViewById(R.id.spinnerCountry);
        checkboxDesigning = findViewById(R.id.checkboxDesigning);
        checkboxSoftwareEngr = findViewById(R.id.checkboxSoftwareEngr);
        checkboxProgramming = findViewById(R.id.checkboxProgramming);
        checkboxWebAppDevelopment = findViewById(R.id.checkboxWebAppDevelopment);
        btnSave = findViewById(R.id.btnSubmit);
        dialog = getProgressDialog(false);
        ageBar.setOnSeekBarChangeListener(this);
    }


    private void fetchUserData() {
        // Initialize Firestore
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        SharedPreferences preferences = getSharedPreferences("Quiz", Context.MODE_PRIVATE);
        showProgressDialog(dialog);
        // Fetch data from "users" collection (replace "userId" with actual user ID)
        String userId = preferences.getString("userId", ""); // Replace with actual logic to get user ID
        db.collection("users").document(userId).get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        DocumentSnapshot document = task.getResult();
                        if (document.exists()) {
                            if (document.contains("name")) {
                                editTextName.setText(document.getString("name"));
                            }

                            if (document.contains("email")) {
                                editTextEmail.setText(document.getString("email"));
                            }

                            if (document.contains("age")) {
                                txtAge.setText("Age: " + String.valueOf(document.getLong("age")));
                                ageBar.setProgress(Integer.parseInt(String.valueOf(document.getLong("age"))));
                            }

                            if (document.contains("gender")) {
                                String gender = document.getString("gender");
                                if ("Male".equalsIgnoreCase(gender)) {
                                    radioMale.setChecked(true);
                                } else if ("Female".equalsIgnoreCase(gender)) {
                                    radioFemale.setChecked(true);
                                }
                            }

                            if (document.contains("country")) {
                                // Set spinner selection dynamically (example logic)
                                String country = document.getString("country");
                                setSpinnerSelection(spinnerCountry, country);
                            }
                            if (document.contains("profileImage")) {
                                imageUrl = document.getString("profileImage");
                                Picasso.get().load(document.getString("profileImage")).into(profileImage);
                            }

                            if (document.contains("skills")) {
                                // Parse skills array
                                for (Object skill : (Iterable<?>) document.get("skills")) {
                                    String skillName = skill.toString();
                                    switch (skillName) {
                                        case "Designing":
                                            checkboxDesigning.setChecked(true);
                                            break;
                                        case "Software Engineering":
                                            checkboxSoftwareEngr.setChecked(true);
                                            break;
                                        case "Programming":
                                            checkboxProgramming.setChecked(true);
                                            break;
                                        case "Web App Development":
                                            checkboxWebAppDevelopment.setChecked(true);
                                            break;
                                    }
                                }
                            }
                            cancelDialog(dialog);
                        } else {
                            cancelDialog(dialog);
                            Toast.makeText(this, "No user data found", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        cancelDialog(dialog);

                        Toast.makeText(this, "Failed to fetch data: " + task.getException(), Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private void setSpinnerAdapter() {
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, countries);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerCountry.setAdapter(adapter);
    }

    private void setSpinnerSelection(Spinner spinner, String value) {
        ArrayAdapter<String> adapter = (ArrayAdapter<String>) spinner.getAdapter();
        for (int i = 0; i < adapter.getCount(); i++) {
            if (adapter.getItem(i).equals(value)) {
                spinner.setSelection(i);
                break;
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == Activity.RESULT_OK) {
            if (data != null) {
                selectedPhotoUri = data.getData();
                loadImageInView();
            } else if (selectedPhotoUri != null) {
                loadImageInView();
            }
        } else {
            selectedPhotoUri = null;
        }
    }

    private void loadImageInView() {
        profileImage.setImageURI(selectedPhotoUri);
    }

    private void uploadImageToCloudinary(String userId, String name, String email, int age, String gender, String country, ArrayList<String> skills, Uri imageUri) {
        MediaManager.get().upload(FileUtils.getPath(getApplicationContext(), imageUri))
                .callback(new UploadCallback() {
                    @Override
                    public void onStart(String requestId) {
                        // Show progress bar or loading indicator
                    }

                    @Override
                    public void onProgress(String requestId, long bytes, long totalBytes) {
                        // Update progress indicator
                    }

                    @Override
                    public void onSuccess(String requestId, Map resultData) {
                        // Get the URL of the uploaded image
                        String imageUrl = (String) resultData.get("secure_url");
                        saveUserDataToFirestore(userId, name, email, age, gender, country, skills, imageUrl); // No image URL

                    }

                    @Override
                    public void onError(String requestId, ErrorInfo error) {
                        saveUserDataToFirestore(userId, name, email, age, gender, country, skills, null); // No image URL

                        // Handle error
                        Toast.makeText(ProfileActivity.this, "Upload failed: " + error.getDescription(), Toast.LENGTH_SHORT).show();
                    }

                    @Override
                    public void onReschedule(String requestId, ErrorInfo error) {
                        // Handle reschedule
                    }
                }).dispatch();
    }

    private void saveUserData() {
        // Validate fields
        if (!validateInputs()) {
            return;
        }

        // Get user data from inputs
        String name = editTextName.getText().toString().trim();
        String email = editTextEmail.getText().toString().trim();
        String ageString = String.valueOf(ageBar.getProgress());
        int age = Integer.parseInt(ageString);

        int selectedGenderId = radioGroupGender.getCheckedRadioButtonId();
        String gender = (selectedGenderId == R.id.radioMale) ? "Male" : "Female";

        String country = spinnerCountry.getSelectedItem().toString();

        // Get selected skills
        ArrayList<String> skills = new ArrayList<>();
        if (checkboxDesigning.isChecked()) skills.add("Designing");
        if (checkboxSoftwareEngr.isChecked()) skills.add("Software Engineering");
        if (checkboxProgramming.isChecked()) skills.add("Programming");
        if (checkboxWebAppDevelopment.isChecked()) skills.add("Web App Development");

        // Get the user ID (from shared preferences)
        SharedPreferences preferences = getSharedPreferences("Quiz", Context.MODE_PRIVATE);
        String userId = preferences.getString("userId", "");
        showProgressDialog(dialog);
        // Start the image upload process if a photo is selected
        if (selectedPhotoUri != null) {
            uploadImageToCloudinary(userId, name, email, age, gender, country, skills, selectedPhotoUri);
        } else {
            saveUserDataToFirestore(userId, name, email, age, gender, country, skills, null); // No image URL
        }
    }

    private void saveUserDataToFirestore(String userId, String name, String email, int age, String gender, String country, ArrayList<String> skills, String imageUrl) {
        // Create a map to store user data
        Map<String, Object> userData = new HashMap<>();
        userData.put("name", name);
        userData.put("email", email);
        userData.put("age", age);
        userData.put("gender", gender);
        userData.put("country", country);
        userData.put("skills", skills);

        // Add the image URL to the data (if it exists)
        if (imageUrl != null) {
            userData.put("profileImage", imageUrl);
        } else if (this.imageUrl != null) {
            userData.put("profileImage", this.imageUrl);

        }

        // Save data to Firestore
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        db.collection("users").document(userId)
                .set(userData)
                .addOnSuccessListener(aVoid -> {
                    cancelDialog(dialog);
                    Toast.makeText(ProfileActivity.this, "User data updated successfully", Toast.LENGTH_SHORT).show();
                })
                .addOnFailureListener(e -> {
                    cancelDialog(dialog);
                    Toast.makeText(ProfileActivity.this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                });
    }

    private boolean validateInputs() {
        String name = editTextName.getText().toString().trim();
        String email = editTextEmail.getText().toString().trim();
        String ageString = String.valueOf(ageBar.getProgress());
        // Validate name
        if (name.isEmpty()) {
            editTextName.setError("Name is required");
            return false;
        }
        // Validate email
        if (email.isEmpty() || !Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            editTextEmail.setError("Invalid email address");
            return false;
        }
        // Validate age
        if (ageString.isEmpty()) {
            Toast.makeText(this, "age is required", Toast.LENGTH_SHORT).show();
            return false;
        }
        /*try {
            int age = Integer.parseInt(ageString);
            if (age < 18) {
                editTextAge.setError("Age must be 18 or older");
                return false;
            }
        } catch (NumberFormatException e) {
            editTextAge.setError("Age must be a valid number");
            return false;
        }*/
        // Validate gender
        if (radioGroupGender.getCheckedRadioButtonId() == -1) {
            Toast.makeText(this, "Please select a gender", Toast.LENGTH_SHORT).show();
            return false;
        }
        // Validate country selection
        if (spinnerCountry.getSelectedItemPosition() == 0) {
            Toast.makeText(this, "Please select a country", Toast.LENGTH_SHORT).show();
            return false;
        }
        // Validate skills selection
        if (!checkboxDesigning.isChecked() && !checkboxSoftwareEngr.isChecked() &&
                !checkboxProgramming.isChecked() && !checkboxWebAppDevelopment.isChecked()) {
            Toast.makeText(this, "Please select at least one skill", Toast.LENGTH_SHORT).show();
            return false;
        }

        return true;
    }


    @Override
    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
        txtAge.setText("Age: " + String.valueOf(progress));
    }

    @Override
    public void onStartTrackingTouch(SeekBar seekBar) {

    }

    @Override
    public void onStopTrackingTouch(SeekBar seekBar) {

    }
}