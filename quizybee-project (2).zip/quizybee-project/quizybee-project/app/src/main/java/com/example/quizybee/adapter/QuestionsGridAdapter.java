package com.example.quizybee.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.example.quizybee.R;
import com.example.quizybee.model.QuestionModel;

import java.util.List;

public class QuestionsGridAdapter extends RecyclerView.Adapter<QuestionsGridAdapter.QuestionViewHolder> {

    private List<QuestionModel> questionList;

    public QuestionsGridAdapter(List<QuestionModel> questionList) {
        this.questionList = questionList;
    }

    @Override
    public QuestionViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_question_grid, parent, false);
        return new QuestionViewHolder(view);
    }

    @Override
    public void onBindViewHolder(QuestionViewHolder holder, int position) {
        QuestionModel question = questionList.get(position);
        holder.bind(position, question);
    }

    @Override
    public int getItemCount() {
        return questionList.size();
    }

    public void updateQuestionStatus(int position, QuestionModel question) {
        if (position >= 0 && position < questionList.size()) {
            questionList.set(position, question);
            notifyItemChanged(position);
        }
    }

    public static class QuestionViewHolder extends RecyclerView.ViewHolder {
        TextView numberText;
        CardView container;

        QuestionViewHolder(View itemView) {
            super(itemView);
            numberText = itemView.findViewById(R.id.question_number);
            container = itemView.findViewById(R.id.container);
        }

        void bind(int position, QuestionModel question) {
            numberText.setText(String.valueOf(position + 1));

            int backgroundRes;
            String selectedAnswer = question.getSelectedAnswer();

            if (question.isReview()) {
                backgroundRes = R.drawable.circle_pink;
            } else if (question.isVisited()) {
                // Question has been visited
                if (!question.isAnswered()) {
                    backgroundRes = R.drawable.circle_red;  // Visited but no answer selected
                } else {
                    backgroundRes = R.drawable.circle_green;  // Answer selected
                }
            } else {
                backgroundRes = R.drawable.circle_gray;  // Not visited yet
            }

            container.setBackgroundResource(backgroundRes);
        }
    }
}