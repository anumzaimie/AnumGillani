package com.example.quizybee.fragment;

import android.app.Dialog;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.example.quizybee.R;
import com.example.quizybee.adapter.LeaderBoardAdapter;
import com.example.quizybee.model.LeaderboardModel;
import com.google.android.gms.tasks.Tasks;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link LeaderboardFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class LeaderboardFragment extends BaseFragment {

    TextView totalUsers;
    RecyclerView recyclerView;
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;
    Dialog dialog;
    public LeaderboardFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment LeaderboardFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static LeaderboardFragment newInstance(String param1, String param2) {
        LeaderboardFragment fragment = new LeaderboardFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        View view = inflater.inflate(R.layout.fragment_leaderboard, container, false);
        intiView(view);
        return view;
    }

    private void intiView(View view) {
        totalUsers = view.findViewById(R.id.total_users);
        recyclerView = view.findViewById(R.id.recycler_view);

        fetchLeaderBoard();
    }

    private void fetchLeaderBoard() {
        dialog=getProgressDialog(false);
        showProgressDialog(dialog);
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        CollectionReference leaderboardRef = db.collection("leaderboard");
        CollectionReference usersRef = db.collection("users");

        leaderboardRef.orderBy("score", Query.Direction.DESCENDING).get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    List<LeaderboardModel> leaderboardItems = new ArrayList<>();
                    List<DocumentSnapshot> sortedSnapshots = queryDocumentSnapshots.getDocuments();

                    if (sortedSnapshots.isEmpty()) {
                        updateUI(leaderboardItems);
                        return;
                    }

                    AtomicInteger processedUsers = new AtomicInteger(0);
                    final int[] currentRank = {1};  // Track current rank
                    Long[] lastScore = {null};      // Track last processed score

                    // Loop through sorted leaderboard documents
                    for (DocumentSnapshot snapshot : sortedSnapshots) {
                        String userId = snapshot.getId();
                        Long scoreObj = snapshot.getLong("score");

                        if (scoreObj == null) {
                            handleProcessedUser(processedUsers, sortedSnapshots.size(), leaderboardItems);
                            continue;
                        }

                        int score = scoreObj.intValue();

                        // Calculate rank - only increment if score is different
                        if (lastScore[0] != null && score < lastScore[0]) {
                            currentRank[0]++;
                        }
                        lastScore[0] = (long) score;

                        final int rank = currentRank[0];  // Store current rank for async callback

                        // Fetch user details from "users" collection
                        usersRef.document(userId).get()
                                .addOnSuccessListener(userSnapshot -> {
                                    String userName = "Unknown User";
                                    if (userSnapshot.exists()) {
                                        String name = userSnapshot.getString("name");
                                        if (name != null && !name.trim().isEmpty()) {
                                            userName = name;
                                        }
                                    }

                                    // Add user to the leaderboard with proper rank
                                    leaderboardItems.add(new LeaderboardModel(
                                            userId,
                                            userName,
                                            score,
                                            rank
                                    ));

                                    handleProcessedUser(processedUsers, sortedSnapshots.size(), leaderboardItems);
                                })
                                .addOnFailureListener(e -> {
                                    leaderboardItems.add(new LeaderboardModel(
                                            userId,
                                            "Unknown User",
                                            score,
                                            rank
                                    ));

                                    Log.e("Leaderboard", "Error fetching user data for ID: " + userId, e);
                                    handleProcessedUser(processedUsers, sortedSnapshots.size(), leaderboardItems);
                                });
                    }
                })
                .addOnFailureListener(e -> {
                    Log.e("Leaderboard", "Error getting leaderboard documents", e);
                    updateUI(new ArrayList<>());
                    showError("Failed to load leaderboard. Please try again.");
                });
    }

    private void handleProcessedUser(AtomicInteger processedUsers, int totalUsers, List<LeaderboardModel> items) {
        if (processedUsers.incrementAndGet() == totalUsers) {
            // Sort by score in descending order first, then by rank
            Collections.sort(items, (a, b) -> {
                int scoreCompare = Integer.compare(b.getScore(), a.getScore());
                if (scoreCompare != 0) {
                    return scoreCompare;
                }
                return Integer.compare(a.getRank(), b.getRank());
            });
            updateUI(items);
        }
    }

    private void updateUI(List<LeaderboardModel> items) {
        if (isAdded() && getContext() != null) {
            recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
            LeaderBoardAdapter adapter = new LeaderBoardAdapter(items);
            recyclerView.setAdapter(adapter);
            totalUsers.setText("Total Users: " + items.size());
            cancelDialog(dialog);
        }
    }
    private void showError(String message) {
        if (isAdded() && getContext() != null) {
            Toast.makeText(getContext(), message, Toast.LENGTH_LONG).show();
            cancelDialog(dialog);
        }
    }


}