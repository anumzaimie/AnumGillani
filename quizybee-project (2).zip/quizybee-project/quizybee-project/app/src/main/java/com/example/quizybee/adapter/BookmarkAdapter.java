package com.example.quizybee.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.quizybee.R;
import com.example.quizybee.model.BookmarkModel;

import java.util.List;

public class BookmarkAdapter extends RecyclerView.Adapter<BookmarkAdapter.ViewHolder> {
    List<BookmarkModel>bookmarkModelList;

    public BookmarkAdapter(List<BookmarkModel> bookmarkModelList) {
        this.bookmarkModelList = bookmarkModelList;
    }

    @NonNull
    @Override
    public BookmarkAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_answer, parent, false);
        return new BookmarkAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull BookmarkAdapter.ViewHolder holder, int position) {
        BookmarkModel model=bookmarkModelList.get(position);
        holder.tvQuestionText.setText(model.getQuestion());
        holder.tvOptionA.setText(model.getOptions().get(0));
        holder.tvOptionB.setText(model.getOptions().get(1));
        holder.tvOptionC.setText(model.getOptions().get(2));
        holder.tvOptionD.setText(model.getOptions().get(3));
    }

    @Override
    public int getItemCount() {
        return bookmarkModelList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView  tvQuestionText, tvOptionA, tvOptionB, tvOptionC, tvOptionD, tvStatus;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvQuestionText = itemView.findViewById(R.id.tv_question_text);
            tvOptionA = itemView.findViewById(R.id.tv_option_a);
            tvOptionB = itemView.findViewById(R.id.tv_option_b);
            tvOptionC = itemView.findViewById(R.id.tv_option_c);
            tvOptionD = itemView.findViewById(R.id.tv_option_d);
            itemView.findViewById(R.id.tv_status).setVisibility(View.GONE);
        }
    }
}
