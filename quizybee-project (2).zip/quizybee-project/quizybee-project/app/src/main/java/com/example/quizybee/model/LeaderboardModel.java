package com.example.quizybee.model;

public class LeaderboardModel {
    private String userId;
    private String userName;
    private int score;
    private int rank;

    // Constructor
    public LeaderboardModel(String userId, String userName, int score, int rank) {
        this.userId = userId;
        this.userName = userName;
        this.score = score;
        this.rank = rank;
    }

    public LeaderboardModel() {
    }

    // Getters and setters
    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }

    public int getRank() {
        return rank;
    }

    public void setRank(int rank) {
        this.rank = rank;
    }
}
