package com.example.quizybee.model;

import java.util.List;

public class BookmarkModel {
    private String userId;
    private String question;
    private List<String> options;

    public BookmarkModel(String userId, String question, List<String> options) {
        this.userId = userId;
        this.question = question;
        this.options = options;
    }

    public BookmarkModel() {
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getQuestion() {
        return question;
    }

    public void setQuestion(String question) {
        this.question = question;
    }

    public List<String> getOptions() {
        return options;
    }

    public void setOptions(List<String> options) {
        this.options = options;
    }
}
