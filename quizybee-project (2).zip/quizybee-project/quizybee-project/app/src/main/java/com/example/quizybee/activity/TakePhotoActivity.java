package com.example.quizybee.activity;

import android.Manifest;
import android.app.Activity;
import android.app.Dialog;
import android.content.ClipData;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;

import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;


import com.example.quizybee.R;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;


public class TakePhotoActivity extends BaseActivity {

    /**
     * Flag to identify camera access permission is requested
     */
    public static final int TAKE_PHOTO_PERMISSION = 101;
    /**
     * Flag to identify gallery access permission is requested
     */
    public static final int CHOOSE_PHOTO_PERMISSION = 102;
    /**
     * Flag to identify camera intent is called
     */
    public static final int TAKE_PHOTO_RESULT_CODE = 110;
    /**
     * Flag to identify gallery intent is called
     */
    public static final int CHOOSE_PHOTO_RESULT_CODE = 120;
    /**
     * Flag to identify gallery intent is called
     */
    public static final int CHOOSE_MULTIPLE_RESULT_CODE = 130;

    public Uri selectedPhotoUri;
    public ActivityResultLauncher<Intent> imagePickerLauncher;
    public boolean isVideo = false;

    public void initializeImagePicker() {
        imagePickerLauncher = this.registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback<ActivityResult>() {
            @Override
            public void onActivityResult(ActivityResult o) {
                if (o.getResultCode() == Activity.RESULT_OK) {
                    if (o.getData() != null) {
                        if (selectedPhotoUri == null)
                            selectedPhotoUri = o.getData().getData();
                        handlePhotoResult();
                    } else
                        handlePhotoResult();

                } else {
                    selectedPhotoUri = null;
                }
            }
        });
    }


    /**
     * show user dialog to select either open camera Or gallery
     */
    protected void showChoosePhotoDialog() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (checkAndRequestPermissions(TakePhotoActivity.this
                    , new String[]{Manifest.permission.READ_MEDIA_IMAGES}, CHOOSE_PHOTO_PERMISSION))
                dispatchChoosePictureIntent("image");
        } else {
            if (checkAndRequestPermissions(TakePhotoActivity.this
                    , new String[]{Manifest.permission.READ_EXTERNAL_STORAGE,
                            Manifest.permission.WRITE_EXTERNAL_STORAGE}, CHOOSE_PHOTO_PERMISSION))
                dispatchChoosePictureIntent("image");
        }
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == CHOOSE_PHOTO_PERMISSION && verifyPermission(grantResults)) {
            dispatchChoosePictureIntent("image");
        } else
            Toast.makeText(this, "permission not granted.", Toast.LENGTH_SHORT).show();
    }

    /**
     * Check build os version and then dispatch single or multiple choose picture intent
     */




    private void handlePhotoResult() {
        Intent resultIntent = new Intent();
        resultIntent.setData(selectedPhotoUri);
        setResult(RESULT_OK, resultIntent);
    }


    /**
     * create and open choose from gallery/photos intent
     */
    public void dispatchChoosePictureIntent(String type) {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType(type + "/*");
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, false);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        imagePickerLauncher.launch(intent);
    }


    /**
     * create and return a file to store the taken image in the device storage
     *
     * @return created file in device storage
     */
    final public File getPhotoFile() {
        // String timeStamp = DateUtils.convertDate(System.currentTimeMillis(), DateUtils.FILE_NAME);
        String imageFileName = "IMG" + "hello";
        File storageDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES);
        File photoFile = null;
        try {
            if (!storageDir.exists())
                storageDir.mkdirs();

            photoFile = File.createTempFile(imageFileName, ".jpg", storageDir);

        } catch (IOException e) {
//            Logger.caughtException(e);
        }
        return photoFile;
    }
    public static boolean checkAndRequestPermissions(Activity activity, String[] permissions, int requestCode) {

        List<String> requiredPerm = new ArrayList<>();
        for (String permission : permissions)
            if (ContextCompat.checkSelfPermission(activity, permission) != PackageManager.PERMISSION_GRANTED)
                requiredPerm.add(permission);

        if (requiredPerm.isEmpty())
            return true;
        String[] mPermission = new String[requiredPerm.size()];
        mPermission = requiredPerm.toArray(mPermission);
        if (mPermission != null)
            activity.requestPermissions(mPermission, requestCode);
        return false;
    }
    public static boolean verifyPermission(int[] grantResults) {
        // at least one result must be checked.
        if (grantResults.length < 1)
            return false;
        // verify that each required permission has been granted, otherwise return false.
        for (int result : grantResults) {
            if (result != PackageManager.PERMISSION_GRANTED)
                return false;
        }
        return true;
    }
}
