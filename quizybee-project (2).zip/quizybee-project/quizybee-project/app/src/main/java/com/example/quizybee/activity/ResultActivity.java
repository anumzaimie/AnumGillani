package com.example.quizybee.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.airbnb.lottie.LottieAnimationView;
import com.example.quizybee.R;
import com.example.quizybee.model.QuestionModel;

import java.util.ArrayList;

public class ResultActivity extends AppCompatActivity {
    private TextView scoreText, timeTakenText, totalQuestionsText, correctText, wrongText, unattemptedText;
    private Button reAttemptBtn, viewAnswersBtn;
    ArrayList<QuestionModel> questionList;
    LottieAnimationView animationView;
    ImageView ivAnim;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);
        initViews();
        getIntentData();
        setClickListeners();

        // Check score percentage and update background
        updateBackgroundBasedOnScore();
    }

    private void initViews() {
        scoreText = findViewById(R.id.scoreText);
        timeTakenText = findViewById(R.id.timeTakenText);
        totalQuestionsText = findViewById(R.id.totalQuestionsText);
        correctText = findViewById(R.id.correctText);
        wrongText = findViewById(R.id.wrongText);
        unattemptedText = findViewById(R.id.unattemptedText);
        reAttemptBtn = findViewById(R.id.reAttemptButton);
        viewAnswersBtn = findViewById(R.id.viewAnswersButton);
        Toolbar toolbar = findViewById(R.id.toolbar);
        animationView = findViewById(R.id.animationView);
        ivAnim = findViewById(R.id.animImageView);

        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().show();
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }
    }

    private void getIntentData() {
        int score = getIntent().getIntExtra("score", 0);
        int totalQuestions = getIntent().getIntExtra("t_ques", 0);
        int correctAnswers = getIntent().getIntExtra("correct", 0);
        int wrongAnswers = getIntent().getIntExtra("wrong", 0);
        int unattempted = getIntent().getIntExtra("unattempted", 0);
        String timeTaken = getIntent().getStringExtra("time_taken");
        questionList = (ArrayList<QuestionModel>) getIntent().getSerializableExtra("questionList");

        // Set values to views
        scoreText.setText(String.valueOf(score));
        timeTakenText.setText(timeTaken + " m");
        totalQuestionsText.setText(String.valueOf(totalQuestions));
        correctText.setText(String.valueOf(correctAnswers));
        wrongText.setText(String.valueOf(wrongAnswers));
        unattemptedText.setText(String.valueOf(unattempted));
    }

    private void setClickListeners() {
        reAttemptBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish(); // This will take user back to the previous screen
            }
        });

        viewAnswersBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ResultActivity.this, AnswerActivity.class);
                intent.putExtra("questionList", new ArrayList<>(questionList));
                startActivity(intent);
            }
        });
    }

    private void updateBackgroundBasedOnScore() {
        int score = getIntent().getIntExtra("score", 0);
        int t_score = getIntent().getIntExtra("t_score", 0);
        float percentage = ((float) score / t_score) * 100;
        if (percentage < 40) {
            ivAnim.setVisibility(View.GONE);
            animationView.setAnimation(R.raw.sad_animation);
            animationView.playAnimation();
        } else {
            ivAnim.setVisibility(View.VISIBLE);
            Animation slideInRight = AnimationUtils.loadAnimation(this, R.anim.slide_pic);
            ivAnim.startAnimation(slideInRight);
            animationView.setAnimation(R.raw.confetti);
            animationView.playAnimation();
        }
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            Intent intent = new Intent(this, TestActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(intent);
            finish();
        }
        return super.onOptionsItemSelected(item);
    }

}
