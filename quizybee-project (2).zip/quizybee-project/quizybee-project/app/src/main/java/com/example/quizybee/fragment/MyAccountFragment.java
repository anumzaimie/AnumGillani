package com.example.quizybee.fragment;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.quizybee.R;
import com.example.quizybee.activity.BookmarkActivity;
import com.example.quizybee.activity.LoginActivity;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link MyAccountFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class MyAccountFragment extends BaseFragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;
    Dialog dialog;
    public MyAccountFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment MyAccountFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static MyAccountFragment newInstance(String param1, String param2) {
        MyAccountFragment fragment = new MyAccountFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @SuppressLint("MissingInflatedId")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_my_account, container, false);
        fetchAccountData(view);
        view.findViewById(R.id.bookmark_lv).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getContext(), BookmarkActivity.class));
            }
        });
        view.findViewById(R.id.lv_logout).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getContext(), LoginActivity.class));

            }
        });
        return view;
    }

    private void fetchAccountData(View view) {
        dialog=getProgressDialog(false);
        showProgressDialog(dialog);
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        CollectionReference leaderboardRef = db.collection("leaderboard");
        CollectionReference usersRef = db.collection("users");
        SharedPreferences preferences = getContext().getSharedPreferences("Quiz", Context.MODE_PRIVATE);
        leaderboardRef.orderBy("score", Query.Direction.DESCENDING).get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    int rank = 1; // Initialize rank
                    int overallScore = 0;
                    boolean userFound = false;

                    for (DocumentSnapshot snapshot : queryDocumentSnapshots) {
                        String userId = snapshot.getId();

                        if (userId.equals(preferences.getString("userId", ""))) {
                            overallScore = snapshot.getLong("score").intValue();
                            userFound = true;
                            break;
                        }
                        rank++;
                    }

                    if (userFound) {
                        // Fetch user name from the 'users' collection
                        int finalOverallScore = overallScore;
                        int finalRank = rank;
                        usersRef.document(preferences.getString("userId", "")).get().addOnSuccessListener(userSnapshot -> {
                            if (userSnapshot.exists()) {
                                String name = userSnapshot.getString("name");

                                // Update the UI with fetched data
                                updateMyAccountUI(name, finalRank, finalOverallScore, view);
                            }
                        }).addOnFailureListener(e -> {
                            cancelDialog(dialog);
                            Log.e("MyAccount", "Error fetching user name: ", e);
                        });
                    } else {
                        cancelDialog(dialog);
                        Log.e("MyAccount", "User not found in leaderboard");
                    }
                })
                .addOnFailureListener(e -> {
                    cancelDialog(dialog);
                    Log.e("MyAccount", "Error fetching leaderboard: ", e);
                });
    }

    // Function to update the UI
    private void updateMyAccountUI(String name, int rank, int score, View view) {
        TextView nameTextView = view.findViewById(R.id.titleText);
        TextView rankTextView = view.findViewById(R.id.rankValue);
        TextView scoreTextView = view.findViewById(R.id.scoreValue);

        nameTextView.setText("" + name);
        rankTextView.setText("" + rank);
        scoreTextView.setText("" + score);
        cancelDialog(dialog);
    }

}