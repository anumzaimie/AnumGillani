package com.example.quizybee.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;

import com.cloudinary.android.MediaManager;
import com.example.quizybee.R;
import com.example.quizybee.fragment.CategoryFragment;
import com.example.quizybee.fragment.LeaderboardFragment;
import com.example.quizybee.fragment.MyAccountFragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationView;

import java.util.HashMap;

public class MainActivity extends AppCompatActivity {

    private DrawerLayout drawerLayout;
    private NavigationView navigationView;
    private BottomNavigationView bottomNavigationView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initCloundinary();
        // Setup Toolbar
        Toolbar toolbar = findViewById(R.id.toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }
        setSupportActionBar(toolbar);

        // Setup Drawer Layout
        drawerLayout = findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();

        // Setup NavigationView
        navigationView = findViewById(R.id.navigation_view);
        navigationView.setNavigationItemSelectedListener(item -> {
            handleDrawerNavigation(item.getItemId());
            drawerLayout.closeDrawers();
            return true;
        });
        View headerView = navigationView.getHeaderView(0);
        TextView tvEmail = headerView.findViewById(R.id.nav_drawer_name);
        tvEmail.setText(getIntent().getStringExtra("email"));
        // Setup BottomNavigationView
        bottomNavigationView = findViewById(R.id.bottom_navigation);
        bottomNavigationView.setOnItemSelectedListener(item -> {
            handleBottomNavigation(item.getItemId());
            return true;
        });

        // Set Default Fragment
        if (savedInstanceState == null) {
            loadFragment(new CategoryFragment());
        }
    }

    private void handleDrawerNavigation(int itemId) {
        Fragment fragment = null;
        if (itemId == R.id.nav_home) {
            fragment = new CategoryFragment();
        } else if (itemId == R.id.nav_leaderboard) {
            fragment = new LeaderboardFragment();
        } else if (itemId == R.id.nav_account) {
            fragment = new MyAccountFragment();
        }
        if (fragment != null) {
            loadFragment(fragment);
        }
    }

    private void handleBottomNavigation(int itemId) {
        Fragment fragment = null;
        if (itemId == R.id.nav_home) {
            fragment = new CategoryFragment();
        } else if (itemId == R.id.nav_leaderboard) {
            fragment = new LeaderboardFragment();
        } else if (itemId == R.id.nav_account) {
            fragment = new MyAccountFragment();
        }
        if (fragment != null) {
            loadFragment(fragment);
        }
    }

    private void loadFragment(Fragment fragment) {
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.fragment_container, fragment)
                .commit();
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the toolbar
        getMenuInflater().inflate(R.menu.profile_menu, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle menu item clicks
        int id = item.getItemId();

        if (id == R.id.action_profile) {
            startActivity(new Intent(getApplicationContext(), ProfileActivity.class));
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
    private void initCloundinary() {
        // Initialize Cloudinary with your Cloud Name, API Key, and API Secret
        MediaManager.init(this, new HashMap<String, String>() {{
            put("cloud_name", "deqsz0rsl");
            put("api_key", "448493749563978");
            put("api_secret", "XBORbJmxHeVsR-l0poXLWdOEz_8");
        }});
    }
}
