package com.example.quizybee.fragment;

import android.app.Dialog;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.view.Window;

import androidx.fragment.app.Fragment;

import com.example.quizybee.R;

import java.util.Objects;

public class BaseFragment extends Fragment {
    public Dialog getProgressDialog(boolean cancelable) {
        Dialog dialog = new Dialog(getContext());
        dialog.getWindow().requestFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.setContentView(R.layout.app_dialog);
        dialog.setCancelable(cancelable);
        return dialog;
    }

    public void cancelDialog(Dialog dialog) {
        requireActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (dialog != null && dialog.isShowing())
                    dialog.dismiss();
            }
        });
    }

    public void showProgressDialog(Dialog dialog) {
        requireActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                dialog.show();
            }
        });
    }
}
