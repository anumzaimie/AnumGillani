package com.example.quizybee.activity;

import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.PagerSnapHelper;
import androidx.recyclerview.widget.RecyclerView;

import com.example.quizybee.R;
import com.example.quizybee.adapter.QuestionsAdapter;
import com.example.quizybee.adapter.QuestionsGridAdapter;
import com.example.quizybee.model.BookmarkModel;
import com.example.quizybee.model.QuestionModel;
import com.example.quizybee.model.QuizSubmission;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.WriteBatch;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class QuestionsActivity extends BaseActivity {

    private RecyclerView questionsView;
    private TextView tvQuesID, timerTV, catNameTV;
    private Button submitB, markB, clearSelB;
    private ImageButton prevQuesB, nextQuesB;
    private ImageView quesListGrid, bookB;
    FirebaseFirestore db;
    private DrawerLayout drawerLayout;
    private QuestionsGridAdapter gridAdapter;
    private RecyclerView questionsGrid;
    List<QuestionModel> questionModels;
    private int currentQuestionIndex = 0;
    private QuestionsAdapter questionsAdapter;
    boolean isBookMark = false;
    private CountDownTimer countDownTimer;
    int totalMarks = 0;
    String quizTime, testId, catId;
    private long timeRemainingInMillis = 0;
    List<BookmarkModel> bookmarkModelList;
    Dialog dialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_questions);
        init();
        catId = getIntent().getStringExtra("cat_id");
        testId = getIntent().getStringExtra("test_id");
        String catName = getIntent().getStringExtra("cat_name");
        quizTime = getIntent().getStringExtra("time");
        totalMarks = Integer.parseInt(getIntent().getStringExtra("t_marks"));
        catNameTV.setText(catName);
        loadQuestions(catId, testId);
        prevQuesB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (currentQuestionIndex > 0) {
                    currentQuestionIndex--;
                    updateQuestion();
                }
            }
        });
        nextQuesB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (currentQuestionIndex < questionModels.size() - 1) {
                    gridAdapter.updateQuestionStatus(currentQuestionIndex, questionModels.get(currentQuestionIndex));
                    currentQuestionIndex++;
                    updateQuestion();
                }
            }
        });
        clearSelB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                questionsAdapter.clearOptionForQuestion(currentQuestionIndex);
            }
        });
        markB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                questionsAdapter.markForReview(currentQuestionIndex);
                gridAdapter.notifyItemChanged(currentQuestionIndex);
            }
        });
        bookB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                isBookMark = !isBookMark;
                questionsAdapter.bookmark(currentQuestionIndex, isBookMark);
                toggleBookmark(isBookMark);
            }
        });
        submitB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showSubmitDialog();
            }
        });

    }

    private void init() {
        drawerLayout = findViewById(R.id.drawer_layout);
        questionsGrid = findViewById(R.id.questions_grid);
        questionsView = findViewById(R.id.questions_view);
        tvQuesID = findViewById(R.id.tv_quesID);
        timerTV = findViewById(R.id.time_remaining);
        catNameTV = findViewById(R.id.category_text);
        submitB = findViewById(R.id.submit_button);
        markB = findViewById(R.id.markB);
        bookB = findViewById(R.id.book_icon);
        clearSelB = findViewById(R.id.clear_selB);
        prevQuesB = findViewById(R.id.prev_questB);
        nextQuesB = findViewById(R.id.next_quesB);
        quesListGrid = findViewById(R.id.ques_list_grid);
        bookmarkModelList = new ArrayList<>();
        dialog = getProgressDialog(false);
        questionsView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(@NonNull RecyclerView recyclerView, int newState) {
                super.onScrollStateChanged(recyclerView, newState);
                if (newState == RecyclerView.SCROLL_STATE_IDLE) {
                    // Get the first completely visible item position
                    LinearLayoutManager layoutManager = (LinearLayoutManager) questionsView.getLayoutManager();
                    if (layoutManager != null) {
                        int visiblePosition = layoutManager.findFirstVisibleItemPosition();
                        if (visiblePosition != RecyclerView.NO_POSITION) {
                            currentQuestionIndex = visiblePosition;
                            updateQuestion(); // Update the question counter or any related UI
                        }
                    }
                }
            }
        });
        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }
        db = FirebaseFirestore.getInstance();
        quesListGrid.setOnClickListener(v -> {
            if (drawerLayout.isDrawerOpen(GravityCompat.END)) {
                drawerLayout.closeDrawer(GravityCompat.END);
            } else {
                drawerLayout.openDrawer(GravityCompat.END);
            }
        });
        findViewById(R.id.close_drawer).setOnClickListener(v -> {
            drawerLayout.closeDrawer(GravityCompat.END);
        });
    }

    private void toggleBookmark(boolean isBookmark) {
        if (isBookmark)
            bookB.setImageResource(R.drawable.baseline_bookmark_24);
        else
            bookB.setImageResource(R.drawable.baseline_bookmark_border_24);
    }

    private void setUpQuestionDrwaerGrid() {
        // Setup questions grid
        questionsGrid.setLayoutManager(new GridLayoutManager(this, 4));
        gridAdapter = new QuestionsGridAdapter(questionModels);
        questionsGrid.setAdapter(gridAdapter);
    }

    private void loadQuestions(String catId, String testId) {
        questionModels = new ArrayList<>();
        showProgressDialog(dialog);
        db.collection("categories")
                .document(catId)
                .collection("test")
                .document(testId)
                .collection("questions")
                .get()
                .addOnSuccessListener(querySnapshot -> {
                    for (QueryDocumentSnapshot document : querySnapshot) {
                        String questionText = document.getString("question");
                        List<String> options = (List<String>) document.get("options");
                        String correctAnswer = document.getString("correctAnswer");

                        questionModels.add(new QuestionModel(questionText, options, correctAnswer));
                    }
                    startCountdownTimer((long) Integer.parseInt(quizTime) * 60 * 1000);
                    PagerSnapHelper snapHelper = new PagerSnapHelper();
                    snapHelper.attachToRecyclerView(questionsView);
                    questionsView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
                    questionsAdapter = new QuestionsAdapter(questionModels, totalMarks);
                    questionsView.setAdapter(questionsAdapter);
                    setUpQuestionDrwaerGrid();
                    updateQuestion();
                    cancelDialog(dialog);
                })
                .addOnFailureListener(e -> {
                    Log.e("FirestoreError", "Error fetching questions: " + e.getMessage());
                    cancelDialog(dialog);
                });
    }

    private void updateQuestion() {
        if (currentQuestionIndex >= 0 && currentQuestionIndex < questionModels.size()) {
            QuestionModel currentQuestion = questionModels.get(currentQuestionIndex);
            // Update UI with current question details
            isBookMark = currentQuestion.isBookmark();
            toggleBookmark(currentQuestion.isBookmark());
            questionModels.get(currentQuestionIndex).setVisited(true);
            gridAdapter.notifyItemChanged(currentQuestionIndex);
            tvQuesID.setText((currentQuestionIndex + 1) + "/" + questionModels.size()); // Update question counter
            ((LinearLayoutManager) questionsView.getLayoutManager()).scrollToPositionWithOffset(currentQuestionIndex, 0); // Ensure the question is visible
        }
    }

    private void startCountdownTimer(long timeInMillis) {
        countDownTimer = new CountDownTimer(timeInMillis, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                timeRemainingInMillis = millisUntilFinished;
                long secondsLeft = millisUntilFinished / 1000;
                long minutes = secondsLeft / 60;
                long seconds = secondsLeft % 60;
                timerTV.setText(String.format("%02d:%02d", minutes, seconds) + " min");
            }

            @Override
            public void onFinish() {
                // Display "Time's Up!" when the timer finishes
                Toast.makeText(QuestionsActivity.this, "Time Up!", Toast.LENGTH_SHORT).show();
                submitQuiz();
            }
        }.start();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Cancel the timer to avoid memory leaks
        if (countDownTimer != null) {
            countDownTimer.cancel();
        }
    }

    @Override
    public void onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.END)) {
            drawerLayout.closeDrawer(GravityCompat.END);
        } else {
            super.onBackPressed();
        }
    }

    private void showSubmitDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(QuestionsActivity.this);
        builder.setTitle("Submit Test");
        builder.setMessage("Are you sure you want to submit test?");
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

                submitQuiz();
                dialog.dismiss();
            }
        });
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }

    private void submitQuiz() {
        showProgressDialog(dialog);
        SharedPreferences pref = getSharedPreferences("Quiz", MODE_PRIVATE);
        QuizSubmission submission = new QuizSubmission(pref.getString("userId", ""), testId, questionsAdapter.getScore());
        CollectionReference submissionsRef = db.collection("quiz_submissions");
        DocumentReference testRef = db.collection("categories").document(catId).collection("test").document(testId); // Reference to the test document
        submissionsRef.add(submission)
                .addOnSuccessListener(documentReference -> {
                    Log.d("QuizSubmit", "Submission added with ID: " + documentReference.getId());
                    testRef.get()
                            .addOnSuccessListener(documentSnapshot -> {
                                Log.d("Quizz", "Test Ref Success");
                                if (documentSnapshot.exists()) {
                                    Log.d("Quizz", "Test Ref Exist");

                                    Integer bestScore = documentSnapshot.getLong("bestScore") != null ? documentSnapshot.getLong("bestScore").intValue() : 0;
                                    // If current score is greater than the bestScore, update the test document
                                    if (questionsAdapter.getScore() > bestScore) {
                                        testRef.update("Best Score", questionsAdapter.getScore())
                                                .addOnSuccessListener(aVoid -> {
                                                    updateLeaderBoard(submission.getUserId());
                                                    Log.d("QuizSubmit", "Best score updated to: " + questionsAdapter.getScore());
                                                })
                                                .addOnFailureListener(e -> {
                                                    cancelDialog(dialog);
                                                    Log.w("QuizSubmit", "Error updating best score", e);
                                                });
                                    } else {
                                        Log.d("Quizz","Get Score is less then bestScore");

                                        updateLeaderBoard(submission.getUserId());
                                    }
                                } else {
                                    Log.d("Quizz","Test Doc not exist");

                                    cancelDialog(dialog);
                                }
                            })
                            .addOnFailureListener(e -> {
                                cancelDialog(dialog);
                                Log.w("QuizSubmit", "Error getting test document", e);
                            });
                })
                .addOnFailureListener(e -> {
                    cancelDialog(dialog);
                    Log.w("QuizSubmit", "Error adding submission", e);
                });
    }

    private void updateLeaderBoard(String userId) {
        DocumentReference leaderboardRef = db.collection("leaderboard").document(userId);
        leaderboardRef.get()
                .addOnSuccessListener(documentSnapshot -> {
                    int overallScore = 0;
                    if (documentSnapshot.exists()) {
                        overallScore = documentSnapshot.getLong("score").intValue();
                    }
                    int newOverallScore = overallScore + questionsAdapter.getScore();
                    Map<String, Object> updatedLeaderboardEntry = new HashMap<>();
                    updatedLeaderboardEntry.put("score", newOverallScore);
                    updatedLeaderboardEntry.put("timestamp", FieldValue.serverTimestamp());

                    leaderboardRef.set(updatedLeaderboardEntry)
                            .addOnSuccessListener(aVoid -> {
                                Log.d("QuizSubmit", "Overall score updated in leaderboard");
                                //updateRankInLeaderboard();
                                saveBookMarkQuestions(userId);

                            })
                            .addOnFailureListener(e -> {
                                cancelDialog(dialog);
                                Log.w("QuizSubmit", "Error updating overall score in leaderboard", e);
                            });
                })
                .addOnFailureListener(e -> {
                    cancelDialog(dialog);
                    Log.w("QuizSubmit", "Error retrieving leaderboard document", e);
                });
    }


    private void saveBookMarkQuestions(String userId) {
        for (QuestionModel model : questionModels) {
            if (model.isBookmark()) {
                bookmarkModelList.add(new BookmarkModel(userId, model.getQuestion(), model.getOptions()));
            }
        }
        if (!bookmarkModelList.isEmpty()) {
            DocumentReference bookmarkRef = db.collection("bookmarks").document(userId);
            for (BookmarkModel model : bookmarkModelList) {
                // Save the bookmark data in Firestore
                bookmarkRef.set(model)
                        .addOnSuccessListener(aVoid -> {
                            Toast.makeText(this, "Test Submitted Successfully", Toast.LENGTH_SHORT).show();
                            moveToResult(); // Navigate to results after successful ranking
                        })
                        .addOnFailureListener(e -> {
                            cancelDialog(dialog);
                            // Error saving the bookmark
                            System.out.println("Error saving bookmark: " + e.getMessage());
                        });
            }
        } else {
            Toast.makeText(this, "Test Submitted Successfully", Toast.LENGTH_SHORT).show();
            moveToResult(); // Navigate to results after successful ranking
        }
    }

    private void moveToResult() {
        int correctCount = questionsAdapter.getCorrectAnswersCount();
        int wrongCount = questionsAdapter.getWrongAnswersCount();
        int unattemptedCount = questionModels.size() - (correctCount + wrongCount);
        long totalTimeInMillis = Long.parseLong(quizTime) * 60 * 1000; // Convert minutes to milliseconds
        String timeTaken = "";
        if (timeRemainingInMillis > 0) {
            long timeTakenInMillis = totalTimeInMillis - timeRemainingInMillis;
            long minutes = (timeTakenInMillis / 1000) / 60;
            long seconds = (timeTakenInMillis / 1000) % 60;
            timeTaken = String.format("%02d:%02d", minutes, seconds);
        } else {
            long minutes = Long.parseLong(quizTime);
            timeTaken = String.format("%02d:00", minutes);
        }
        Intent intent = new Intent(getApplicationContext(), ResultActivity.class);
        intent.putExtra("score", questionsAdapter.getScore());
        intent.putExtra("t_score", totalMarks);
        intent.putExtra("t_ques", questionModels.size());
        intent.putExtra("correct", correctCount);
        intent.putExtra("wrong", wrongCount);
        intent.putExtra("unattempted", unattemptedCount);
        intent.putExtra("time_taken", timeTaken);
        intent.putExtra("questionList", new ArrayList<>(questionModels));
        cancelDialog(dialog);
        startActivity(intent);
    }

}