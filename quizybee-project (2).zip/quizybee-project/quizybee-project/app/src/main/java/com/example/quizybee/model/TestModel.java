package com.example.quizybee.model;

public class TestModel {
    private String testID;
    private String name;
    private String catId;

    //private int time;


    public TestModel(String testID, String name,String catId) {
        this.testID = testID;
        this.name = name;
        this.catId=catId;
    }

    public String getCatId() {
        return catId;
    }

    public void setCatId(String catId) {
        this.catId = catId;
    }

    public String getTestID() {
        return testID;
    }

    public void setTestID(String testID) {
        this.testID = testID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
