package com.example.quizybee.activity;

import android.app.Dialog;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.quizybee.R;
import com.example.quizybee.adapter.BookmarkAdapter;
import com.example.quizybee.model.BookmarkModel;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;
import java.util.List;

public class BookmarkActivity extends BaseActivity {
    private RecyclerView recyclerView;
    private BookmarkAdapter adapter;
    private List<BookmarkModel> bookmarkList = new ArrayList<>();
    Dialog dialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_bookmark);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        init();
    }

    public void init() {
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar()!=null){
            getSupportActionBar().show();
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }
        recyclerView = findViewById(R.id.recyclerViewBookmarks);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        dialog=getProgressDialog(false);

        fetchBookmarks();
    }

    private void fetchBookmarks() {
        showProgressDialog(dialog);
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        SharedPreferences pref = getSharedPreferences("Quiz", MODE_PRIVATE);
        db.collection("bookmarks")
                .whereEqualTo("userId", pref.getString("userId","")) // Filter by userId
                .get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    if (!queryDocumentSnapshots.isEmpty()) {
                        bookmarkList = queryDocumentSnapshots.toObjects(BookmarkModel.class);
                        adapter = new BookmarkAdapter(bookmarkList);
                        recyclerView.setAdapter(adapter);
                        cancelDialog(dialog);
                    }else
                        Toast.makeText(this, "Bookmark Found!", Toast.LENGTH_SHORT).show();
                    cancelDialog(dialog);
                })
                .addOnFailureListener(e -> {
                    cancelDialog(dialog);
                    Toast.makeText(this, "Error,Try again!", Toast.LENGTH_SHORT).show();
                    System.err.println("Error fetching bookmarks: " + e.getMessage());
                });
    }
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
          finish();
        }
        return super.onOptionsItemSelected(item);
    }
}