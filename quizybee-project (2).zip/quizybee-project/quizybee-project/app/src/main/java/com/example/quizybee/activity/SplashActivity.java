package com.example.quizybee.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import com.example.quizybee.R;

public class SplashActivity extends AppCompatActivity {

    private TextView subTitle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_splash);
        subTitle = findViewById(R.id.subtitle);
        // Typeface typeface = ResourcesCompat.getFont()
        View splashImage = findViewById(R.id.imageView3);
        Animation slideAnim = AnimationUtils.loadAnimation(this, R.anim.slide_in);
        splashImage.startAnimation(slideAnim);


        Animation anim = AnimationUtils.loadAnimation(this, R.anim.myanim);
        subTitle.setAnimation(anim);


        new Thread() {
            @Override
            public void run() {
                try {
                    sleep(3000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }


                Intent intent = new Intent(SplashActivity.this, LoginActivity.class);
                startActivity(intent);
                SplashActivity.this.finish();
            }

        }.start();
    }
}